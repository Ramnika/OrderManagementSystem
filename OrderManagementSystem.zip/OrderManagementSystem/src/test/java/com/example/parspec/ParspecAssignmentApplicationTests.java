package com.example.parspec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParspecAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
