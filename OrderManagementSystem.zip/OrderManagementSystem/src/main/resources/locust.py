from locust import HttpUser, task, between

class OrderUser(HttpUser):
    # Wait time between tasks (1 to 5 seconds)
    wait_time = between(1, 5)

    @task
    def create_order(self):
        # Simulate a POST request to create an order
        self.client.post("/orders", json={
            "userId": "123",
            "orderId": "456",
            "itemIds": "[\"item1\", \"item2\"]",
            "totalAmount": 100.50
        })