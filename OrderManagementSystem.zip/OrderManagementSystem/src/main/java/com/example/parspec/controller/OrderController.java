package com.example.parspec.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.parspec.exception.OrderNotFoundException;
import com.example.parspec.model.Order;
import com.example.parspec.service.OrderService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
@Slf4j
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Map<String, Object>> createOrder(@RequestBody Order order) {
        log.info("Received request to create order: {}", order.getOrderId());
        String orderId = orderService.createOrder(order);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Order received and queued for processing.");
        response.put("orderId", orderId);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{orderId}/status")
    public ResponseEntity<Map<String, Object>> getOrderStatus(@PathVariable String orderId) {
        log.info("Received request to fetch status for order: {}", orderId);
        String status = orderService.getOrderStatus(orderId);

        // Create a structured response
        Map<String, Object> response = new HashMap<>();
        response.put("orderId", orderId);
        response.put("status", status);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @ExceptionHandler(OrderNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleOrderNotFoundException(OrderNotFoundException ex) {
        log.error("Order not found: {}", ex.getMessage());
        return ex.getMessage();
    }
}