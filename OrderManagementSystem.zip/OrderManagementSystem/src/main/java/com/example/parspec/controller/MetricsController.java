package com.example.parspec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.parspec.service.MetricsService;

import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@RestController
@RequestMapping("/metrics")
@Slf4j
public class MetricsController {

    @Autowired
    private MetricsService metricsService;

    @GetMapping
    public Map<String, Object> getMetrics() {
        log.info("Received request to fetch metrics");
        return metricsService.getMetrics();
    }
}