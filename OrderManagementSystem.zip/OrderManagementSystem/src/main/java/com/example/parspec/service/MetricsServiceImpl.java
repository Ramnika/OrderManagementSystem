package com.example.parspec.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.parspec.model.Order;
import com.example.parspec.repository.OrderRepository;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MetricsServiceImpl implements MetricsService {

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Map<String, Object> getMetrics() {
        log.info("Fetching metrics");

     // Fetch total orders processed
        long totalOrdersProcessed = orderRepository.count();

        // Initialize a map with all possible statuses and default count 0
        Map<String, Long> orderStatusCounts = new HashMap<>();
        orderStatusCounts.put("Pending", 0L);
        orderStatusCounts.put("Processing", 0L);
        orderStatusCounts.put("Completed", 0L);

     // Fetch order status counts from the database
        // Assuming countByStatus returns a List<Object[]> like [status, count]
        List<Object[]> dbStatusCounts = orderRepository.countByStatus();

        // Update the initialized map with counts from the database
        for (Object[] row : dbStatusCounts) {
            String status = (String) row[0];  // First element is status (String)
            Long count = (Long) row[1];       // Second element is count (Long)
            orderStatusCounts.put(status, count);
        }

        // Log the order status counts for debugging
        log.info("Order status counts: {}", orderStatusCounts);

        // Calculate average processing time
        double averageProcessingTimeSeconds = calculateAverageProcessingTime();

        // Create the response
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("totalOrdersProcessed", totalOrdersProcessed);
        metrics.put("averageProcessingTimeSeconds", averageProcessingTimeSeconds);
        metrics.put("orderStatusCounts", orderStatusCounts);

        return metrics;
    }
    
    private double calculateAverageProcessingTime() {
        // Fetch all completed orders
        List<Order> completedOrders = orderRepository.findByStatus("Completed");

        // Calculate the total processing time
        long totalProcessingTime = completedOrders.stream()
                .mapToLong(Order::getProcessingTime)
                .sum();

        // Calculate the average processing time
        if (completedOrders.isEmpty()) {
            return 0.0; // Avoid division by zero
        }
        return (double) totalProcessingTime / completedOrders.size();
    }
}