package com.example.parspec.queue;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.parspec.model.Order;
import com.example.parspec.repository.OrderRepository;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
@Slf4j
public class OrderProcessor {

    @Autowired
    private OrderQueue orderQueue;

    @Autowired
    private OrderRepository orderRepository;

    //Create a thread pool with 50 threads
    private final ExecutorService executorService = Executors.newFixedThreadPool(50);

    // Batch size for database writes
    private static final int BATCH_SIZE = 100;

    @PostConstruct
    public void init() {
        for (int i = 0; i < 50; i++) {
            executorService.submit(() -> {
                List<Order> batch = new ArrayList<>(BATCH_SIZE);
                while (true) {
                    try {
                        Order order = orderQueue.getNextOrder();
                        processOrder(order, batch);

                        // Save batch if it reaches the batch size
                        if (batch.size() >= BATCH_SIZE) {
                            saveBatch(batch);
                            batch.clear();
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            });
        }
    }

    private void processOrder(Order order, List<Order> batch) throws InterruptedException {
        log.info("Processing order: {}", order.getOrderId());

        // Record the start time
        LocalDateTime startTime = LocalDateTime.now();

        // Update status to Processing
        order.setStatus("Processing");
        batch.add(order);

        // Simulate processing time
        Thread.sleep(new Random().nextInt(10000)); // Simulate processing time (1-10 seconds)

        // Update status to Completed
        order.setStatus("Completed");

        // Calculate processing time
        LocalDateTime endTime = LocalDateTime.now();
        long processingTime = Duration.between(startTime, endTime).getSeconds();
        order.setProcessingTime(processingTime);

        // Add to batch
        batch.add(order);
    }

    private void saveBatch(List<Order> batch) {
        log.info("Saving batch of {} orders", batch.size());
        orderRepository.saveAll(batch);
    }
}