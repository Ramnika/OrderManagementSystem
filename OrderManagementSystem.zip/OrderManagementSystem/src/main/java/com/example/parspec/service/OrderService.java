package com.example.parspec.service;

import com.example.parspec.model.Order;

public interface OrderService {
    String createOrder(Order order);
    String getOrderStatus(String orderId);
}