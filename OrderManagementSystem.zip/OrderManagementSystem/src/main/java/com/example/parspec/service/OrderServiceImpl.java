package com.example.parspec.service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.parspec.exception.OrderNotFoundException;
import com.example.parspec.model.Order;
import com.example.parspec.queue.OrderQueue;
import com.example.parspec.repository.OrderRepository;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderQueue orderQueue;

    @Override
    public String createOrder(Order order) {
        log.info("Creating order: {}", order.getOrderId());
        orderRepository.save(order);
        orderQueue.addOrder(order);
        return order.getOrderId(); // Return the orderId
    }

    @Override
    public String getOrderStatus(String orderId) {
        log.info("Fetching status for order: {}", orderId);
        Order order = orderRepository.findByOrderId(orderId);
        if (order == null) {
            throw new OrderNotFoundException("Order not found with ID: " + orderId);
        }
        return order.getStatus();
    }
}