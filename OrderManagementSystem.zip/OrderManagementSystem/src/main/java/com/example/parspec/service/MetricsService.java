package com.example.parspec.service;

import java.util.Map;

public interface MetricsService {
    Map<String, Object> getMetrics();
}